module.exports = {
    user: 'postgres',
    host: '127.0.0.1',
    database: 'cert',
    password: 'kissit2001',
    port: "8061"
};